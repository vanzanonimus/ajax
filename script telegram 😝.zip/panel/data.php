<?php 
$nik = "🌀[RESULT] ADMIN BANANA🌀";
$sender = "adminbanana@vanz.com";
?>